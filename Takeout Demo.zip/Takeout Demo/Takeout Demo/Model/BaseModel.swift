//
//  BaseModel.swift
//  Takeout Demo
//
//  Created by Thomas Lau on 2023/1/7.
//

import Foundation

struct BaseModel {
    
    var itemName: String?
    var itemPrice: String?
    var itemImageUrl: String?
    var itemSubImageUrl: String?
}
