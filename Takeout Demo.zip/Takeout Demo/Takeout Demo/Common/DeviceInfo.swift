//
//  DeviceInfo.swift
//  Takeout Demo
//
//  Created by Thomas Lau on 2023/1/8.
//
import Foundation
import UIKit

class DeviceInfo {
    public static func osName() -> String {
        return UIDevice.current.systemName
    }
    
    public static func osVersion() -> String {
        return UIDevice.current.systemVersion
    }
    
    public static func deviceType() -> String {
        return osName() + " " + osVersion()
    }

    // 是否iPhone刘海屏
    static func isIPhoneNotchScreen() -> Bool {
        var result = false
        if UIDevice.current.userInterfaceIdiom != .phone {
            return result
        }
        if #available(iOS 11.0, *) {
            guard let mainWindow = UIApplication.shared.connectedScenes
                    .map({ $0 as? UIWindowScene })
                    .compactMap({ $0 })
                    .first?.windows.first else { return false }
            
            if mainWindow.safeAreaInsets.bottom > 0.0 {
                result = true
            }
        }
        return result
    }
    
    /// 顶部状态栏高度（包括安全区）
    static func statusBarHeight() -> CGFloat {
        var statusBarHeight: CGFloat = 0
        if #available(iOS 13.0, *) {
            let scene = UIApplication.shared.connectedScenes.first
            guard let windowScene = scene as? UIWindowScene else { return 0 }
            guard let statusBarManager = windowScene.statusBarManager else { return 0 }
            statusBarHeight = statusBarManager.statusBarFrame.height
        } else {
            statusBarHeight = UIApplication.shared.statusBarFrame.height
        }
        return statusBarHeight
    }
}
