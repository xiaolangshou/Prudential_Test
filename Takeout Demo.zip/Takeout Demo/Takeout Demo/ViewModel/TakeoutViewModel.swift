//
//  TakeoutViewModel.swift
//  Takeout Demo
//
//  Created by Thomas Lau on 2023/1/7.
//

import UIKit

class TakeoutViewModel: NSObject, CAAnimationDelegate {
    
    var totalPrice = 0
    var addedIndexArr: [Int] = []
    var friesImageView = UIImageView()
    var coffeeImageView = UIImageView()
    var burgerImageView = UIImageView()

    func addItem(vc: ViewController,
                 index: Int,
                 price: String,
                 addOnBtn: UIButton,
                 friesImageView: UIImageView,
                 cafeImageView: UIImageView,
                 burgerImageView: UIImageView) {
        
        self.friesImageView = friesImageView
        self.coffeeImageView = cafeImageView
        self.burgerImageView = burgerImageView
        
        if !addedIndexArr.contains(index) {
            addedIndexArr.append(index)
        } else {
            return
        }
        
        if let priceNum = Int(price) {
            self.totalPrice += priceNum
        }
        
        switch index {
        case 0:
            vc.addFries(addOnBtn: addOnBtn)
            animationFunc(itemView: friesImageView, itemSize: vc.friesSize, addOnBtn: addOnBtn, offsetX: 10, offsetY: -25)
        case 1:
            vc.addCoffee(addOnBtn: addOnBtn)
            animationFunc(itemView: cafeImageView, itemSize: vc.cafeSize, addOnBtn: addOnBtn, offsetX: 40, offsetY: -90)
        case 2:
            vc.addBurger(addOnBtn: addOnBtn)
            animationFunc(itemView: burgerImageView, itemSize: vc.burgerSize, addOnBtn: addOnBtn, offsetX: 90, offsetY: -35)
        default:
            break
        }
    }
    
    func animationFunc(itemView: UIImageView, itemSize: CGFloat, addOnBtn: UIButton, offsetX: CGFloat, offsetY: CGFloat) {
        
        let animation2 = CABasicAnimation.init(keyPath: "position")
        animation2.beginTime = CACurrentMediaTime()
        animation2.isRemovedOnCompletion = false
        animation2.fillMode = .forwards
        animation2.delegate = self
        //设置动画初始位置
        animation2.fromValue = NSValue.init(cgPoint: CGPoint.init(x: addOnBtn.layer.position.x,
                                                                  y: addOnBtn.layer.position.y + 100))
       //设置动画目的位置
        animation2.toValue = NSValue.init(cgPoint: CGPoint.init(x: addOnBtn.layer.position.x - itemSize/2 - offsetX,
                                                                y: addOnBtn.layer.position.y + itemSize * 0.5 + 245 + offsetY))
       //设置动画速率
        animation2.timingFunction = CAMediaTimingFunction.init(name: .easeIn)
        //添加动画
        itemView.layer.add(animation2, forKey: "move-layer")
        
        let animation = CABasicAnimation(keyPath: "bounds.size")
        animation.fromValue = NSValue(cgSize: CGSize.init(width: itemSize/2, height: itemSize/2))
        animation.toValue = NSValue(cgSize: CGSize.init(width: itemSize,
                                                        height: itemSize))
        itemView.layer.add(animation, forKey: "Image-expend")

        let group = CAAnimationGroup.init()
        group.duration = 0.5
        group.animations = [animation, animation2]

        itemView.layer.add(group, forKey: "group-layer")
    }
    
    func callUser() {
        
    }
    
    func openMap() {
        
    }
    
    func pay() {
        
    }
    
    func getDataFromBackEnd() -> [BaseModel] {
        
        let modelArr = [BaseModel.init(itemName: "FRIES",
                                       itemPrice: "4",
                                       itemImageUrl: "薯条",
                                       itemSubImageUrl: nil),
                        BaseModel.init(itemName: "LATTE",
                                       itemPrice: "3",
                                       itemImageUrl: "咖啡",
                                       itemSubImageUrl: nil),
                        BaseModel.init(itemName: "BURGER",
                                       itemPrice: "6",
                                       itemImageUrl: "汉堡",
                                       itemSubImageUrl: nil)]
        
        return modelArr
    }
    
    func updateTotalPrice(priceTextField: UITextField) {
        
        let color = UIColor.init(red: 79/256, green: 79/256, blue: 79/256, alpha: 1)
        let strOne = "\(totalPrice)"
        let attrStr = NSMutableAttributedString.init(string: strOne)
        attrStr.addAttributes([NSAttributedString.Key.font: UIFont.boldSystemFont(ofSize: 43),
                               NSAttributedString.Key.foregroundColor: color],
                              range: NSRange.init(location: 0, length: strOne.count))
    
        
        let strTwo = "$"
        let attrStrTwo = NSMutableAttributedString.init(string: strTwo)
        attrStrTwo.addAttributes([NSAttributedString.Key.font: UIFont.boldSystemFont(ofSize: 25),
                               NSAttributedString.Key.foregroundColor: color],
                              range: NSRange.init(location: 0, length: strTwo.count))
        
        attrStr.append(attrStrTwo)
        priceTextField.attributedText = attrStr
    }
    
    func animationDidStart(_ anim: CAAnimation) {
        self.friesImageView.isHidden = false
        self.coffeeImageView.isHidden = false
        self.burgerImageView.isHidden = false
    }
    
}
