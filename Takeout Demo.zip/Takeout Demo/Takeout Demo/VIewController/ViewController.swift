//
//  ViewController.swift
//  Takeout Demo
//
//  Created by Thomas Lau on 2023/1/7.
//

import UIKit
import SnapKit

class ViewController: UIViewController {
    
    static let shared = ViewController()
    
    let topView = TopView()
    let bannerView = BannerView()
    let plateView = PlateView()
    let addressView = AddressView()
    let totalPriceTextField = UITextField()
    let payBtn = UIButton()
    
    let burgerImageView = UIImageView()
    let cafeImageView = UIImageView()
    let friesImageView = UIImageView()
    
    let friesSize: CGFloat = 110
    let cafeSize: CGFloat = 130
    let burgerSize: CGFloat = 150
    
    let viewModel = TakeoutViewModel()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupView()
        getData()
    }
    
    func getData() {
        bannerView.cellDataArray = viewModel.getDataFromBackEnd()
        
        bannerView.bannerAddBtnTap = { [weak self] (index, price, addOnBtn) in
            guard let self = self else { return }

            self.viewModel.addItem(vc: self,
                                   index: index,
                                   price: price,
                                   addOnBtn: addOnBtn,
                                   friesImageView: self.friesImageView,
                                   cafeImageView: self.cafeImageView,
                                   burgerImageView: self.burgerImageView)
            self.viewModel.updateTotalPrice(priceTextField: self.totalPriceTextField)
        }
    }
    
    func setupView() {
        
        view.addSubview(topView)
        topView.snp.makeConstraints { make in
            make.top.equalTo(DeviceInfo.statusBarHeight())
            make.left.right.equalToSuperview()
            make.height.equalTo(73)
        }
        
        view.addSubview(bannerView)
        bannerView.snp.makeConstraints { make in
            make.left.right.equalToSuperview()
            make.height.equalTo(286)
            make.top.equalTo(topView.snp_bottom)
        }
        
        view.addSubview(plateView)
        plateView.snp.makeConstraints { make in
            make.left.right.equalToSuperview()
            make.top.equalTo(bannerView.snp.bottom)
            make.height.equalTo(245)
        }
        
        view.addSubview(addressView)
        addressView.snp.makeConstraints { make in
            make.left.right.equalToSuperview()
            make.height.equalTo(60)
            make.top.equalTo(plateView.snp.bottom)
        }
        
        view.addSubview(payBtn)
        payBtn.snp.makeConstraints { make in
            make.right.equalToSuperview()
            make.top.equalTo(addressView.snp.bottom)
            make.height.equalTo(65)
            make.width.equalTo(143)
            make.bottom.equalTo(-UIScreen.safeAreaBottomHeight)
        }
        payBtn.setBackgroundImage(UIImage.init(named: "Rectangle"), for: UIControl.State.normal)
        payBtn.setTitle("Pay", for: UIControl.State.normal)
        payBtn.titleLabel?.font = UIFont.boldSystemFont(ofSize: 32)
        payBtn.addTarget(self, action: #selector(payBtnTapped), for: UIControl.Event.touchUpInside)
        
        view.addSubview(totalPriceTextField)
        totalPriceTextField.snp.makeConstraints { make in
            make.left.equalTo(20)
            make.top.equalTo(addressView.snp.bottom)
            make.height.equalTo(65)
            make.right.equalTo(payBtn.snp.left)
            make.bottom.equalTo(-UIScreen.safeAreaBottomHeight)
        }
        totalPriceTextField.isUserInteractionEnabled = false
    }
    
    func addBurger(addOnBtn: UIButton) {
        
        if !self.view.subviews.contains(burgerImageView) {
            self.view.addSubview(burgerImageView)
            burgerImageView.snp.makeConstraints { make in
                make.size.equalTo(burgerSize)
                make.left.equalTo(self.plateView.plateBackImageView.snp.left).offset(10)
                make.top.equalTo(self.plateView.plateBackImageView.snp.top).offset(-25)
            }
            burgerImageView.image = UIImage.init(named: "盘子_汉堡")
            if self.view.subviews.contains(friesImageView) {
                self.view.bringSubviewToFront(friesImageView)
            }
        }
    }
    
    func addCoffee(addOnBtn: UIButton) {
        if !self.view.subviews.contains(cafeImageView) {
            self.view.addSubview(cafeImageView)
            cafeImageView.snp.makeConstraints { make in
                make.size.equalTo(cafeSize)
                make.centerX.equalTo(plateView.plateBackImageView.snp.centerX).offset(12)
                make.top.equalTo(-75)
            }
            cafeImageView.image = UIImage.init(named: "盘子_咖啡")
            if self.view.subviews.contains(friesImageView) {
                self.view.bringSubviewToFront(friesImageView)
            }
        }
    }

    func addFries(addOnBtn: UIButton) {

        if !self.view.subviews.contains(friesImageView) {
            self.view.addSubview(friesImageView)
            friesImageView.snp.makeConstraints { make in
                make.size.equalTo(friesSize)
                make.centerY.equalTo(self.plateView.snp.centerY).offset(-20)
                make.right.equalTo(-70)
            }
            friesImageView.image = UIImage.init(named: "盘子_薯条")
            friesImageView.isHidden = true
        }
    }
    
    @objc func payBtnTapped() {
        print(#function)
        viewModel.pay()
    }
}

