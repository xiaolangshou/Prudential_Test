//
//  UIScreen+Extension.swift
//  Takeout Demo
//
//  Created by Thomas Lau on 2023/1/8.
//

import UIKit

extension UIScreen {
    
    static var safeAreaBottomHeight: CGFloat {
        return DeviceInfo.isIPhoneNotchScreen() ? 49 : 0
    }
}
