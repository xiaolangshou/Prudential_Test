//
//  AddressView.swift
//  Takeout Demo
//
//  Created by Thomas Lau on 2023/1/8.
//

import UIKit

class AddressView: UIView {
    
    let addressPinImageView = UIImageView()
    let addressDetailLabel = UILabel()
    let callBtn = UIButton()

    override init(frame: CGRect) {
        super.init(frame: frame)
        
        setupView()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func setupView() {
        
        self.addSubview(addressPinImageView)
        addressPinImageView.snp.makeConstraints { make in
            make.width.equalTo(25)
            make.height.equalTo(33)
            make.left.equalTo(22)
            make.centerY.equalToSuperview()
        }
        addressPinImageView.image = UIImage.init(named: "地图_大头针")
        
        self.addSubview(callBtn)
        callBtn.snp.makeConstraints { make in
            make.width.height.equalTo(33)
            make.centerY.equalToSuperview()
            make.right.equalTo(-32)
        }
        callBtn.setBackgroundImage(UIImage.init(named: "拨号"), for: UIControl.State.normal)
        callBtn.addTarget(self, action: #selector(callBtnTapped), for: UIControl.Event.touchUpInside)
        
        self.addSubview(addressDetailLabel)
        addressDetailLabel.snp.makeConstraints { make in
            make.left.equalTo(addressPinImageView.snp.right).offset(17)
            make.centerY.equalToSuperview()
            make.right.equalTo(callBtn.snp.left).offset(-17)
        }
        addressDetailLabel.text = "Dongcheng District Metro Cultural Building"
        addressDetailLabel.font = UIFont.systemFont(ofSize: 14)
        addressDetailLabel.textColor = UIColor.init(red: 96/256, green: 96/256, blue: 96/256, alpha: 1)
        addressDetailLabel.numberOfLines = .zero
        addressDetailLabel.lineBreakMode = .byWordWrapping
    }
    
    @objc func callBtnTapped() {
        print(#function)
    }
}

