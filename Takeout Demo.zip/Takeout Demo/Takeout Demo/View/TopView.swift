//
//  MainView.swift
//  Takeout Demo
//
//  Created by Thomas Lau on 2023/1/8.
//

import UIKit
import SnapKit

class TopView: UIView {
    
    let topBarView = UIStackView()
    let topBarImageView = UIImageView()
    let topRecomendBtn = UIButton()
    let topBuggerBtn = UIButton()
    let topDrinkBtn = UIButton()
    let topSnackBtn = UIButton()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        setupView()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setupTopBarView() {
        
        topBarView.distribution = .fillEqually
        topBarView.alignment = .center
        topBarView.axis = .horizontal
        topRecomendBtn.setImage(UIImage.init(named: "顶部推荐"), for: UIControl.State.normal)
        topRecomendBtn.imageView?.contentMode = .scaleAspectFit
        topBuggerBtn.setImage(UIImage.init(named: "顶部汉堡"), for: UIControl.State.normal)
        topBuggerBtn.imageView?.contentMode = .scaleAspectFit
        topDrinkBtn.setImage(UIImage.init(named: "顶部水杯"), for: UIControl.State.normal)
        topDrinkBtn.imageView?.contentMode = .scaleAspectFit
        topSnackBtn.setImage(UIImage.init(named: "顶部小吃"), for: UIControl.State.normal)
        topSnackBtn.imageView?.contentMode = .scaleAspectFit
        
        topBarView.addArrangedSubview(topRecomendBtn)
        topBarView.addArrangedSubview(topBuggerBtn)
        topBarView.addArrangedSubview(topDrinkBtn)
        topBarView.addArrangedSubview(topSnackBtn)
        
        self.addSubview(topBarImageView)
        topBarImageView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
        topBarImageView.image = UIImage.init(named: "Rectangle")
        
        self.addSubview(topBarView)
        topBarView.snp.makeConstraints { make in
            make.edges.equalTo(topBarImageView.snp.edges)
        }
    }
    
    func setupView() {
        
        setupTopBarView()
    }
}
