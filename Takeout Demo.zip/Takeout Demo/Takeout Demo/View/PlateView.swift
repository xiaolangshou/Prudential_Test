//
//  PlateView.swift
//  Takeout Demo
//
//  Created by Thomas Lau on 2023/1/8.
//

import UIKit

class PlateView: UIView {
    
    let plateBackImageView = UIImageView()
    let topLineView = UIView()

    override init(frame: CGRect) {
        super.init(frame: frame)
        
        setupView()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setupView() {
        
        self.addSubview(topLineView)
        topLineView.snp.makeConstraints { make in
            make.left.right.equalToSuperview()
            make.height.equalTo(1)
            make.top.equalToSuperview()
        }
        topLineView.backgroundColor = UIColor.init(red: 242/256, green: 241/256, blue: 241/256, alpha: 1)
        
        self.addSubview(plateBackImageView)
        plateBackImageView.snp.makeConstraints { make in
            make.left.top.equalTo(59)
            make.right.bottom.equalTo(-59)
        }
        plateBackImageView.image = UIImage.init(named: "盘子")
    }
}
