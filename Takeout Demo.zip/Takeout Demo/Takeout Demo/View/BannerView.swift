//
//  BannerView.swift
//  Takeout Demo
//
//  Created by Thomas Lau on 2023/1/8.
//

import UIKit

class BannerView: UIView {
    
    var cellDataArray: [BaseModel]? {
        didSet {
            if let cellDataArray = cellDataArray {
                reloadTheData(cellArray: cellDataArray)
            }
        }
    }
    
    var cellViewArray: [BannerCellView] = []
    
    private var _backView = UIView()
    var scrollView = UIScrollView()
    
    let bigStarImageView = UIImageView()
    let mediumStarImageView = UIImageView()
    let smallStarImageView = UIImageView()
    
    var bannerAddBtnTap: ((Int, String, UIButton)->(Void))?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        setupView()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func setupView() {
        
        self.addSubview(_backView)
        _backView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
        bigStarImageView.image = UIImage.init(named: "star_big")
        bigStarImageView.contentMode = .scaleAspectFill
        
        mediumStarImageView.image = UIImage.init(named: "star_medium")
        mediumStarImageView.contentMode = .scaleAspectFill
        
        smallStarImageView.image = UIImage.init(named: "star_small")
        smallStarImageView.contentMode = .scaleAspectFill
        _backView.addSubview(bigStarImageView)
        _backView.addSubview(mediumStarImageView)
        _backView.addSubview(smallStarImageView)
        
        self.addSubview(scrollView)
        scrollView.delegate = self
        scrollView.alwaysBounceHorizontal = true
        scrollView.isPagingEnabled = true
        scrollView.indicatorStyle = .white
    }
    
    func reloadTheData(cellArray: [BaseModel]) {
        
        layoutIfNeeded()
        
        scrollView.frame = self.bounds
        scrollView.delegate = self
        scrollView.contentSize = CGSize(width: self.frame.size.width * CGFloat(cellArray.count), height: self.frame.size.height)
        
        for (i, item) in cellArray.enumerated() {
            let cellView = BannerCellView(frame: CGRect(x: CGFloat(i) * CGFloat(self.frame.size.width), y: 0, width: self.frame.size.width, height: self.frame.size.height))
            cellView.bannerCellUpdateData = { [weak self] itemData in
                guard let self = self else { return }
                if itemData.itemName == "FRIES" {
                    self.bigStarImageView.snp.remakeConstraints { make in
                        make.top.equalTo(41)
                        make.right.equalTo(-165)
                        make.width.equalTo(25)
                        make.height.equalTo(27)
                    }
                    
                    self.smallStarImageView.snp.remakeConstraints { make in
                        make.right.equalTo(-155)
                        make.top.equalTo(114)
                        make.width.equalTo(11)
                        make.height.equalTo(13)
                    }
                    
                    self.mediumStarImageView.snp.remakeConstraints { make in
                        make.left.equalTo(25)
                        make.top.equalTo(141)
                        make.width.equalTo(15)
                        make.height.equalTo(17)
                    }
                }
            }
            cellView.data = item
            cellView.addBtnTap = { [weak self] addOnBtn in
                guard let self = self else { return }
                self.bannerAddBtnTap?(i, item.itemPrice ?? "", addOnBtn)
            }
            scrollView.addSubview(cellView)
            cellViewArray.append(cellView)
        }
    }
    
    
}

extension BannerView: UIScrollViewDelegate {
    
    func movement(view: UIImageView, fromPoint: CGPoint, toPoint: CGPoint) {
        
        let animation = CABasicAnimation(keyPath: "position")
        animation.beginTime = CACurrentMediaTime()
        animation.isRemovedOnCompletion = false
        animation.fillMode = .forwards
        animation.fromValue = NSValue.init(cgPoint: fromPoint)
        animation.toValue = NSValue.init(cgPoint: toPoint)
        animation.timingFunction = CAMediaTimingFunction.init(name: .easeIn)
        view.layer.add(animation, forKey: "move-layer")
    }
    
    func opacitySet(view: UIView, transparent: Bool, duration: CFTimeInterval) {
        let animation: CAKeyframeAnimation = CAKeyframeAnimation()
        animation.duration = duration
        animation.keyPath = "opacity"
        let valuesArray:[NSNumber] = [NSNumber(value: 0.95 as Float),
                                      NSNumber(value: 0.85 as Float),
                                      NSNumber(value: 0.35 as Float),
                                      NSNumber(value: 0.05 as Float),
                                      NSNumber(value: 0.0 as Float)]
        
        let valuesArray2:[NSNumber] = [NSNumber(value: 0.0 as Float),
                                      NSNumber(value: 0.05 as Float),
                                      NSNumber(value: 0.35 as Float),
                                      NSNumber(value: 0.85 as Float),
                                      NSNumber(value: 0.95 as Float)]
        
        if transparent {
            animation.values = valuesArray
        } else {
            animation.values = valuesArray2
        }
        animation.fillMode = .forwards
        animation.isRemovedOnCompletion = false
        view.layer.add(animation, forKey: nil)
        view.layer.add(animation, forKey: nil)
    }
    
    func scrollViewWillBeginDragging(_ scrollView: UIScrollView) {
        let page = Int(scrollView.contentOffset.x / scrollView.frame.size.width)
        
        // 找出当前cell,然后隐藏title和price
        opacitySet(view: self.cellViewArray[page].itemTitleLabel, transparent: true, duration: 0.5)
        opacitySet(view: self.cellViewArray[page].itemPriceLabel, transparent: true, duration: 0.5)
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        
        let page = Int(scrollView.contentOffset.x / scrollView.frame.size.width)
        
        opacitySet(view: self.cellViewArray[page].itemTitleLabel, transparent: false, duration: 0)
        opacitySet(view: self.cellViewArray[page].itemPriceLabel, transparent: false, duration: 0)
        
        let friesBigStarPoint = CGPoint.init(x: 187, y: 70)
        let friesSmallStarPoint = CGPoint.init(x: 210, y: 135)
        let friesMediumStarPoint = CGPoint.init(x: 30, y: 170)
        
        let coffeeBigStarPoint = CGPoint.init(x: 180, y: 230)
        let coffeeSmallStarPoint = CGPoint.init(x: 186, y: 110)
        let coffeeMediumStarPoint = CGPoint.init(x: 40, y: 240)
        
        let burgerBigStarPoint = CGPoint.init(x: 40, y: 220)
        let burgerSmallStarPoint = CGPoint.init(x: 185, y: 250)
        let burgerMediumStarPoint = CGPoint.init(x: 45, y: 80)
        
        if page == 0 {
            movement(view: self.bigStarImageView,
                     fromPoint: coffeeBigStarPoint,
                     toPoint: friesBigStarPoint)
            
            movement(view: self.smallStarImageView,
                     fromPoint: coffeeSmallStarPoint,
                     toPoint: friesSmallStarPoint)
            
            movement(view: self.mediumStarImageView,
                     fromPoint: coffeeMediumStarPoint,
                     toPoint: friesMediumStarPoint)
            // 找出当前cell,然后显示title和price
            
        } else if page == 1 {
            movement(view: self.bigStarImageView,
                     fromPoint: friesBigStarPoint,
                     toPoint: coffeeBigStarPoint)
            
            movement(view: self.smallStarImageView,
                     fromPoint: friesSmallStarPoint,
                     toPoint: coffeeSmallStarPoint)
            
            movement(view: self.mediumStarImageView,
                     fromPoint: friesMediumStarPoint,
                     toPoint: coffeeMediumStarPoint)
        } else if page == 2 {
            movement(view: self.bigStarImageView,
                     fromPoint: coffeeBigStarPoint,
                     toPoint: burgerBigStarPoint)
            
            movement(view: self.smallStarImageView,
                     fromPoint: coffeeSmallStarPoint,
                     toPoint: burgerSmallStarPoint)
            
            movement(view: self.mediumStarImageView,
                     fromPoint: coffeeMediumStarPoint,
                     toPoint: burgerMediumStarPoint)
        }
    }
}

class BannerCellView: UIView {
    
    let itemImageView = UIImageView()
    let itemTitleLabel = UILabel()
    let itemPriceLabel = UILabel()
    let addBtn = UIButton()
    
    var data: BaseModel? {
        didSet {
            if let data = data {
                updateData(data: data)
            }
        }
    }
    var addBtnTap: ((UIButton)->(Void))?
    var bannerCellUpdateData: ((BaseModel) -> (Void))?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        setupView()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func updateData(data: BaseModel) {
        
        itemImageView.image = UIImage.init(named: data.itemImageUrl ?? "")
        itemTitleLabel.text = data.itemName
        itemPriceLabel.text = (data.itemPrice ?? "") + "$"
        
        bannerCellUpdateData?(data)
    }
    
    func setupView() {
        
        self.addSubview(itemImageView)
        itemImageView.snp.makeConstraints { make in
            make.width.equalTo(240)
            make.height.equalTo(270)
            make.top.equalTo(36)
            make.left.equalToSuperview()
        }
        itemImageView.contentMode = .scaleAspectFill
        
        self.addSubview(itemTitleLabel)
        itemTitleLabel.snp.makeConstraints { make in
            make.height.equalTo(27)
            make.top.equalTo(79)
            make.right.equalTo(-37)
        }
        itemTitleLabel.textColor = UIColor.init(red: 235/256, green: 92/256, blue: 119/256, alpha: 1)
        itemTitleLabel.font = UIFont.boldSystemFont(ofSize: 32)
        itemTitleLabel.textAlignment = .right
        
        self.addSubview(addBtn)
        addBtn.snp.makeConstraints { make in
            make.width.height.equalTo(100)
            make.bottom.equalToSuperview()
            make.right.equalTo(-30)
        }
        addBtn.setBackgroundImage(UIImage.init(named: "添加"), for: UIControl.State.normal)
        addBtn.addTarget(self, action: #selector(addBtnTapped), for: UIControl.Event.touchUpInside)
        
        self.addSubview(itemPriceLabel)
        itemPriceLabel.snp.makeConstraints { make in
            make.left.equalTo(itemImageView.snp.right)
            make.right.equalTo(-37)
            make.top.equalTo(itemTitleLabel.snp.bottom)
            make.height.equalTo(23)
        }
        itemPriceLabel.textAlignment = .right
        itemPriceLabel.font = UIFont.systemFont(ofSize: 24)
        itemPriceLabel.textColor = UIColor.init(red: 235/256, green: 92/256, blue: 119/256, alpha: 1)
    }
    
    @objc func addBtnTapped() {
        addBtnTap?(self.addBtn)
        print(#function)
    }
}
